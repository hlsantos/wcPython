# setup.py
from distutils.core import setup

setup(
    name='wcpapi',
    version='8.0.454.13',
    packages=['wcpapi'],
    author='hls',
    author_email='hsantos@isdg.net',
    description='Wildcat! Python API'
)
