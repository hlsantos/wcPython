Wildcat! Python API (wcPAPI)
(c) Copyright 1998-2023 Santronics Software, Inc. All Rights Reserved.

Version   : 8.0
Build     : 454.13
Date      : 02/01/2023

WCSDK Website: http://www.winserver.com/public/wcsdk

------
About:
------

wcpapi-readme.txt



-----------------
Revision History:
-----------------

Build    Date      Author  Comments
-----    --------  ------  -------------------------------------------
454.13   02/01/23  HLS     - Start of wcPAPI module
-----    --------  ------  -------------------------------------------

