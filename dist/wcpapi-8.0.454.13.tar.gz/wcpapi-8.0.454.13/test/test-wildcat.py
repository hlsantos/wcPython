#import wildcat

#import constants_h
#import wctype_h
#import wctypemw_h
#import wcgtype_h
from wcpapi.constants_h import *


#print(f"NUM_USER_SECURITY: {constants_h.NUM_USER_SECURITY}")
print(f"NUM_USER_SECURITY: {NUM_USER_SECURITY}")

