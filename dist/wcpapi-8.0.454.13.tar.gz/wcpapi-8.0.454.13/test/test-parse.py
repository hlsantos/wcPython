import re

def parse1(arg):
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?P<arg_ptr>\[\]?)\[(?P<arg_size>[a-zA-Z_]+)\]$')
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?P<arg_ptr>\[\]*)\[(?P<arg_size>[a-zA-Z_]+)\]$')
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?:\[\])?\[(?P<arg_size>[a-zA-Z_]+)\]$')
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?P<arg_ptr>\[\]*)(?:\[(?P<arg_size>[a-zA-Z_]+)\])$')
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?P<arg_ptr>\[\]*)(?:\[(?P<arg_size>[a-zA-Z_]+)\]|)$')
    pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?:\[(?P<arg_ptr>\[\])?(?P<arg_size>[a-zA-Z_]+)\])?$')
    #pattern = re.compile(r'^(?P<arg_name>[a-zA-Z_]+)(?:\[(?:\[\])*(?P<arg_size>[a-zA-Z_]+)\])?$')

    print("---------", arg)
    match = pattern.match(arg)
    if match:

       print("  ",match.groupdict())

       """
       arg_name = match.group("arg_name")
       arg_ptr = match.group("arg_ptr")
       arg_size = match.group("arg_size")
       print(arg_name, arg_ptr, arg_size)
       """
    else:
       print(match)

arg1 = "name[SIZE_SECURITY_NAME]"
arg2 = "name[][SIZE_SECURITY_NAME]"



parse1(arg1)
parse1(arg2)


