import ctypes
import sys
import wcpapi
from wcpapi import wcserver_h, wcserror_h
from wcpapi.wcserver_h import *
from wcpapi.wcserror_h import *
import datetime

def FormatFileTime(lft):
    ft = ctypes.wintypes.FILETIME(lft.dwLowDateTime, lft.dwHighDateTime)
    st = SYSTEMTIME()
    ctypes.windll.kernel32.FileTimeToSystemTime(ctypes.byref(ft), ctypes.byref(st))
    dt = datetime.datetime(st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond)
    return dt.strftime("%Y%m%d %H:%M:%S")

def GetLowestMessage(cnum, msg):
    msg.Conference = cnum
    return GetNextMessage(msg)

def GetHighestMessage(cnum, msg):
    msg.Conference = cnum
    return GetPrevMessage(msg)

def doit(cnum, bList):
    msg = TMsgHeader()
    total = GetTotalMessagesInConference(cnum)
    low = GetLowMessageNumber(cnum)
    high = GetHighMessageNumber(cnum)
    print("Total: {} Low: {} High: {}: ".format(total, low, high))

    if not GetLowestMessage(cnum, msg):
        print("Error {:08X} GetLowestMessage({})".format(ctypes.GetLastError(), cnum))
        return

    print("Lo: {:5} id: {:7} | {}".format(msg.Number, msg.Id, msg.To.Name))

    msg = TMsgHeader()
    if not GetHighestMessage(cnum, msg):
        print("Error ", GetWildcatErrorStr(ctypes.GetLastError()))
        #print("Error {:08X} GetHighestMessage({})".format(ctypes.GetLastError(), cnum))
        return
    print("Hi: {:5} id: {:7} | {}".format(msg.Number, msg.Id, msg.To.Name))

    if not bList:
        return

    print("-" * 76)
    print("{:5s}| {:9s} | {:6s} | {:9s} | {:8s} | {:17s} | {:40s} | {:40s} | {}".format(
        "", "Id", "Number", "Size", "Flags", "Date", "To.Name", "From.Name", "Subject"
    ))
    print("-" * 76)

    dwCnt = 0
    dwSize = 0
    msg = TMsgHeader()

    if cnum == 9:
        Id = 1307923408; Number = 48855
        Id = 1307716572; Number = 48842;

        if GetMessageById(cnum, Id,msg):
           print("Zoom")
        else:
           print(f"error GetMessageById({cnum},{Id}) ",GetLastError())
        input()

    else:
        msg.Conference = cnum


    while GetNextMessage(ctypes.byref(msg)):
        dwCnt += 1
        dwSize += msg.MsgSize
        print("{:5} {:9} | {:6} | {:9} | {:08x} | {:17} | {:40} | {:40} | {}".format(
            dwCnt, msg.Id, msg.Number, msg.MsgSize, msg.MailFlags,
            FormatFileTime(msg.MsgTime), msg.To.Name, msg.From.Name, msg.Subject
        ))
        ##if sys.stdin.readable() and sys.stdin.read(1) == "\x1b": break
    print("-" * 76)
    print("Total Msgs: {} Total Size: {}".format(dwCnt, dwSize))

if 0:
   if len(sys.argv) < 2:
       print("usage: wcListMail conf# [/L]")
       print("show low/high message numbers.")
       print("/l will display headers")
       exit(1)

   cnum = int(sys.argv[1]) if len(sys.argv) >= 2 else 0
   bList = len(sys.argv) >= 3 and sys.argv[2].lower() == "/l"
else:
   cnum = 9
   bList = True

server = "ntbbs"

if not WildcatServerConnectSpecific(None,server):   exit(1)
if not WildcatServerCreateContext(): exit(1)
try:
    if not LoginSystem():
        print("Error {} w/ login".format(ctypes.GetLastError()))
        exit(1)
    doit(cnum, bList)
finally:
    WildcatServerDeleteContext()

