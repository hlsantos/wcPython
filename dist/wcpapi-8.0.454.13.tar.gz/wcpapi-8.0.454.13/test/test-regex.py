import re

struct_fields = '''
   BOOL Yes;
   char Security[NUM_USER_SECURITY][SIZE_SECURITY_NAME];
   char ExtraBaudResults[10][SIZE_MODEM_STRING];
   char From[28];
   char message[3][80];
   BOOL InviteToChat;
   '''

#print(struct_fields)

sre = r"(\w+)\s+(\w+)\[?([^;]+)?\]?;"
#sre = r"(\w+)\s+(\w+)\[([^;]+)?\]?;"
#sre = r"(\w+)\s+(\w+)\[?([^\]]+)?\]?;"
#sre = r"(\w+)\s+(\w+)\[?([^\[\;]+)?\]?;"
#sre = r"(\w+)\s+(\w+)\[?([^\[\;]+)?\]?;"

sre = r"(\w+)\s+(\w+)(\[([^;]+)?\])?;"   # works


for field in re.finditer(sre, struct_fields):
    print(f"|{field.group(1):15}", end="")
    print(f"|{field.group(2):25}", end="")
    print(f"|{field.group(3) or '':40}|", end="")
    print("")



