# testing CWildcat Class

#import os
import ctypes
#from ctypes import wintypes
#from ctypes.wintypes import LONG, DWORD, WORD, BOOL, FILETIME

import wcpapi
from wcpapi import wcserver_h
from wcpapi.wcserver_h import *

#-------------------------------------------------------------------
def wcGetConnectedServer():
    server_name_buffer = ctypes.create_string_buffer(1024)
    if wcserver_h.GetConnectedServer(server_name_buffer, ctypes.sizeof(server_name_buffer)):
       return server_name_buffer.value.decode();
    else:
       return ""

def wcGetChallengeString():
    challenge_buffer = ctypes.create_string_buffer(1024)
    if wcserver_h.GetChallengeString(challenge_buffer, ctypes.sizeof(challenge_buffer)):
       return challenge_buffer.value.decode();
    else:
       return ""

def wcWildcatServerCreateContextFromChallenge():
    challenge = wcGetChallengeString();
    return WildcatServerCreateContextFromChallenge(challenge)

def wcWildcatServerConnectSpecific(h, server):
    return WildcatServerConnectSpecific(h, server)

def wcSetNodeActivity(act):
    print(act)
    SetNodeActivity(act)

def wcGetConnectionId():
    return GetConnectionId();

def wcGetNode():
    return GetNode();

def wcWildcatLoggedIn(u = None):
    if not u:
       return WildcatLoggedIn(None)
    return WildcatLoggedIn(u)
#-------------------------------------------------------------------

def ini_get(key):
    #if key == "wildcat.autoconnect": return True
    if key == "wildcat.autoconnect": return False
    if key == "wildcat.server": return "NTBBS"
    return None

def WcInitialize(quiet=True):
    if wcGetConnectedServer() == "":
        server = ini_get("wildcat.server")
        if server != "":
            if not quiet:
                print("- Connecting to " + server)
            result = wcWildcatServerConnectSpecific(None, server)
        else:
            if not quiet:
                print("- Connecting to default server")
            result = WildcatServerConnect(None)
        if not result and not quiet:
            print("! Error {}: Connecting to Wildcat! Server: {}".format(
                wcGetLastError(), server))
            return False
    else:
        if not quiet:
            print("- Already Connected")

    cid = wcGetConnectionId()
    if cid != 0:
        wcSetNodeActivity("PWE: Session Already Established")
        return True

    autoconnect = ini_get("wildcat.autoconnect")
    if not quiet:
        print("- debug: autoconnect: ",autoconnect)

    if wcWildcatServerCreateContextFromChallenge():
        if not quiet:
            print("- User Session Reestablished!!")
        wcSetNodeActivity("PAPI: Session Reestablished")
        return True

    if WildcatServerCreateContext(None):
        if not quiet:
            print("- New Context Created!")
        wcSetNodeActivity("PAPI: New Context Created")
        return True

    if not quiet:
        print("! Error {}: Creating new session".format(wcGetLastError()))
    return False

class CWildcat:
    def __init__(self, quiet=True):
        self.Quiet    = quiet
        self.SessType = 0
        self.hContext = 0
        self.Active   = 0
        self.Active   = WcInitialize(quiet)
        self.IniOptions = {
            "wildcat.autoconnect": ini_get("wildcat.autoconnect"),
            "wildcat.server": ini_get("wildcat.server")
        }
        self.User = self.GetUser()
        self.Cid = self.ConnectionId()

    def __del__(self):
        self.RestoreContext()
        if self.Active:
           if not self.Quiet: print("- deleting context")
           WildcatServerDeleteContext()


    def GetUser(self):
        u = TUser()
        WildcatLoggedIn(u)
        return u

    def Node(self):            return wcGetNode()
    def ConnectionId(self):    return wcGetConnectionId()
    def CallType(self):        return wcGetCallType()
    def CallTypeStr(self):     return wcGetCallTypeStr()
    def SessionTypeStr(self):  return wcGetSessionTypeStr()
    def LoginSystem(self):     return self.LoginSystemContext()
    def LoginConfig(self,pwd): return self.LoginConfigContext(pwd)

    def LoginSystemContext(self):
        self.SessType = wcWildcatLoggedIn()

        if self.SessType == clSessionSystem:
            return True

        self.hContext = GetWildcatThreadContext()
        if self.hContext <= 0:
            return False

        if self.SessType > clSessionNone:
            if not wcSetWildcatThreadContext(0):
                return False
            if not WildcatServerCreateContext():
                wcSetWildcatThreadContext(self.hContext)
                self.hContext = 0
                return False
            wcSetContextPeerAddress(wcGetCallerId())

        if not LoginSystem():
            if self.SessType > clSessionNone:
                WildcatServerDeleteContext()
                wcSetWildcatThreadContext(self.hContext)
            self.hContext = 0
            return False

        return True

    def LoginConfigContext(self, pwd=""):
        if not extension_loaded("wcsmw"):
            dl("php_wcsmw.dll")
        if self.SessType != clSessionConfig:
            if not self.LoginSystemContext():
                return False
            if not wcLoginConfig(pwd):
                self.RestoreContext()
                return False
            self.SessType = clSessionConfig
        return True

    def RestoreContext(self):
        if self.hContext != 0:
            if self.SessType == clSessionConfig:
                WildcatServerDeleteContext()
            SetWildcatThreadContext(self.hContext)
            self.hContext = 0
            self.SessType = clSessionNone

#----------------------------------------------------------

class CWildcat_Test:
    def __init__(self, quiet=True):
        self.SessType = 0
        self.hContext = 0
        self.Active   = 0  #WcInitialize(quiet)
        self.IniOptions = {
            "wildcat.autoconnect": ini_get("wildcat.autoconnect"),
            "wildcat.server": ini_get("wildcat.server")
        }
        self.User = 0 #self.GetUser()
        self.Cid =  0 #self.ConnectionId()

    def __del__(self):
        #self.RestoreContext()
        if self.Active:
            WildcatServerDeleteContext()


def test():
    wcat = CWildcat(False)

    print("Node            : ",wcat.Node())
    print("Connected server: ",wcGetConnectedServer())
    print("Total Users     : ",GetTotalUsers())
    print("LoginSytem()    : ",wcat.LoginSystem())
    print("<<<pause>>",end="")
    input()


#--------------------------------------------- Main


print("*"*60)

test()
print("testing out of class scope")
input()



