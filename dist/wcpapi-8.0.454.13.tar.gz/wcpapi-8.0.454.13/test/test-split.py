import re

line = "   enum           {item1, item2};"

new_line = re.sub(r'enum\s*{', '', line)
print(new_line)


line = "const DWORD WILDCAT_FRAMEWORK_VERSION    = 1;"

line1 = line.lstrip("const DWORD").lstrip()
line2 = line.replace("const DWORD","").lstrip()
print(f"line : [{line}]")
print(f"line1: [{line1}]")
print(f"line2: [{line2}]")


