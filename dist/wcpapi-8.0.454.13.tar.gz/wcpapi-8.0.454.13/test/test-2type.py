import re

def create_type_header(input_file, output_file):
    # Open the C header file
    with open(input_file, "r") as f: header_file_contents = f.read()

    # Remove C-based comments
    header_file_contents = re.sub(r"/\*.*?\*/", "", header_file_contents, flags=re.DOTALL)
    header_file_contents = re.sub(r"//.*", "", header_file_contents)

    # Find all struct definitions
    struct_defs = re.findall(r"typedef\s+(enum|struct\s+tag[\w]+)\s*\{([^}]+)\}\s*(\w+);", header_file_contents)

    for i, struct in enumerate(struct_defs):
        print(f"{i:2} {struct[0]:30} {struct[2]}")

def create_type_const0(input_file, output_file):
    # Open the C header file
    with open(input_file, "r") as f: header_file_contents = f.read()

    # Remove C-based comments
    header_file_contents = re.sub(r"/\*.*?\*/", "", header_file_contents, flags=re.DOTALL)
    header_file_contents = re.sub(r"//.*", "", header_file_contents)

    # Find all "typedef struct|enum" definitions
    pat_struct = r"typedef\s+(enum|struct\s+tag[\w]+)\s*\{([^}]+)\}\s*(\w+);"
    struct_defs  = re.findall(pat_struct, header_file_contents)

    # Find all "enum" definitions
    pat_enum = r"enum\s+{*\{([^}]+)\}\s*(\w+)?;"
    enum_defs = re.findall(pat_enum, header_file_contents)

    print("** struct_defs **");
    for i, struct in enumerate(struct_defs):
        print(f"{i:2} {struct[0]:30} {struct[2]}")
    print("** enum_defs **");
    for i, enum in enumerate(enum_defs):
        print(f"{i:2} {enum[0]:30} {enum[1]}")


def create_type_const1(input_file, output_file):
    # Open the C header file
    with open(input_file, "r") as f: header_file_contents = f.read()

    # Remove C-based comments
    header_file_contents = re.sub(r"/\*.*?\*/", "", header_file_contents, flags=re.DOTALL)
    header_file_contents = re.sub(r"//.*", "", header_file_contents)

    # Find all "typedef struct|enum" and "enum" definitions
    defs = re.findall(pat, header_file_contents)

    print("** defs **");
    for i, d in enumerate(defs):
        print(f"{i:2} {d[0]:30} |{d[1]}|{d[2]}|")

def create_type_const(input_file, output_file):
    # Open the C header file
    with open(input_file, "r") as f: header_file_contents = f.read()

    # Remove C-based comments
    header_file_contents = re.sub(r"/\*.*?\*/", "", header_file_contents, flags=re.DOTALL)
    header_file_contents = re.sub(r"//.*", "", header_file_contents)

    # Find all "typedef struct|enum" and "enum" definitions
    pat = r"typedef\s+(enum|struct\s+tag[\w]+)\s*\{([^}]+)\}\s*(\w+);|enum\s+(?:{*\{([^}]+)\}\s*)?(\w+)?;"
    pat = r"typedef\s+(enum|struct\s+tag[\w]+)\s*\{([^}]+)\}\s*(\w+);"
    pat = r"typedef\s+(enum|struct\s+tag[\w]+)\s*\{([^}]+)\}\s*(\w+);|enum\s+{*\{([^}]+)\}\s*(\w+)?;"
    defs = re.findall(pat, header_file_contents)

    print("** defs **");
    for i, d in enumerate(defs):
        if d[0] == "enum":
          print(f"{i:2} {d[0]:30} |{d[1]}|{d[2]}|")
        else:
          print(f"{i:2} {d[0]:30} {d[2]}")


# main

#create_type_header("include\\wctype.h","")
create_type_const0("include\\wctype.h","")
#create_type_const("include\\wctype.h","")


input()
