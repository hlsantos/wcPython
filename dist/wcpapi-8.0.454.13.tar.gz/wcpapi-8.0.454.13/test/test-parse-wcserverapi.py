# ----------------------------------------------------------
# WcPAPI testing
# ----------------------------------------------------------

import re
import os
import ctypes
from ctypes import wintypes

import wcpapi
from wcpapi import wcserver_h
from wcpapi.wcserver_h import *

#-----------------------------------------------------------
# Helper functions
#-----------------------------------------------------------

def GetWildcatServerStr(wsi):
    major_version = (wsi.ServerVersion & 0xffff0000) >> 16
    minor_version = wsi.ServerVersion & 0x0000ffff
    major_build = (wsi.ServerBuild & 0xffff0000) >> 16
    minor_build = wsi.ServerBuild & 0x0000ffff
    return f"{major_version}.{minor_version}.{major_build}.{minor_build}"

def wcGetConnectedServer():
    server_name_buffer = ctypes.create_string_buffer(1024)
    if GetConnectedServer(server_name_buffer, ctypes.sizeof(server_name_buffer)):
       return server_name_buffer.value.decode();
    else:
       return ""

#-----------------------------------------------------------
# MAIN
#-----------------------------------------------------------

print("#"*60)
print("* wcPython")
print("- Version:",GetWildcatVersion()," Build:",GetWildcatBuild())

serverName = "NTBBS"
serverName = "hdev21"
serverName = ""

if not WildcatServerConnectSpecific(None,serverName.encode()):
   error_code = ctypes.GetLastError()
   print("! connect error code: {error_code} 0x{hex(error_code)}")
   exit(1)

if not WildcatServerCreateContext():
   print("Error Creating Wildcat! Server Context")
   exit(1)

if not LoginSystem():
   print("LoginSystem() error")

print("- Connected to server:",wcGetConnectedServer())

# ----------------------------------------------------------
if 0:
   mw = TMakewild()
   if GetMakewild(mw):
      print("** TMakewild")
      print("%-23s: %s" % ("Version", hex(mw.Version)))
      print("%-23s: %s" % ("BBSName", mw.BBSName))
      print("%-23s: %s" % ("BuildDate", mw.BuildDate))
      print("%-23s: %s" % ("DomainName", mw.DomainName))
      print("%-23s: %s" % ("SysopName", mw.SysopName))
      print("%-23s: %s" % ("City", mw.City))
      print("%-23s: %s" % ("FirstCall", mw.FirstCall))
      print("%-23s: %s" % ("PacketId", mw.PacketId))
      print("%-23s: %s" % ("RegString", mw.RegString))
      print("%-23s: %s" % ("SystemAccess", mw.SystemAccess))
      print("%-23s: %s" % ("MaxLoginAttempts", mw.MaxLoginAttempts))
      print("%-23s: %s" % ("LoginAskLocation", mw.LoginAskLocation))
      print("%-23s: %s" % ("NewUserSecurity", mw.NewUserSecurity))
      print("%-23s: %s" % ("DefaultExt", mw.DefaultExt))
      print("%-23s: %s" % ("DateFormat", mw.DateFormat))
      print("%-23s: %s" % ("TimeFormat", mw.TimeFormat))
      print("%-23s: %s" % ("DefaultDomain", mw.DefaultDomain))
      print("%-23s: %s" % ("AllowLogonEmail", mw.AllowLogonEmail))
      print("%-23s: %s" % ("CaseSensitivePasswords", mw.CaseSensitivePasswords))
      print("%-23s: %s" % ("MsgHeaderCaseMode", mw.MsgHeaderCaseMode))
      print("%-23s: %s" % ("SpamAllowAuth", mw.SpamAllowAuth))
      print("%-23s: %s" % ("InstalledComponents", mw.InstalledComponents))
      print("%-23s: %s" % ("WindowsCharset", mw.WindowsCharset))
      print("%-23s: %s" % ("LogonUserNameOnly", mw.LogonUserNameOnly))
   else:
      print("MakeWild error:",hex(GetLastError()))

# ----------------------------------------------------------
if 0:
   # create a TUser struct to hold the result
   user = TUser()
   tid =  DWORD()

   # call the GetUserById function
   id = 228332
   id = 1
   if GetUserById(id, user, ctypes.byref(tid)):
      try:
        print(f"Thread ID: {tid.value}")
        print(f"UserId: {user.Info.Id} found:", user.Info.Name)
        seclist = [user.Security[i].Item for i in range(NUM_USER_SECURITY) if user.Security[i].Item]
        print(seclist)
        """
        secs = ""
        for i in range(NUM_USER_SECURITY):
           if user.Security[i].Item != "": secs += f"{user.Security[i].Item:15}"
        print(f"{secs}")
        """
      except Exception as e:
        print(f"Error with name {user.Info.Name}",e)
      print("")

   else:
      print("User not found.")


# ----------------------------------------------------------
if 0:
   print("- Total Users: ",GetTotalUsers())
   tid = DWORD()
   user = TUser()
   sortkey = UserNameKey
   sortkey = UserLastNameKey
   sortkey = UserIdKey
   n = 0
   while GetNextUser(sortkey, user, tid):
      n += 1
      try:
        seclist = [user.Security[i].Item for i in range(NUM_USER_SECURITY) if user.Security[i].Item]
        l = len(seclist)
        if l == 0 or l > 1:
           print(f"* id: {user.Info.Id:<5} {user.Info.Name:<25} ",end="")
           print(seclist)
      except Exception as e:
        print(f"Error with User Name {user.Info.Name}:",e)

# ----------------------------------------------------------
if 0:
   server_info = TWildcatServerInfo()
   if GetWildcatServerInfo(ctypes.byref(server_info)):
       print("** TWildcatServerInfo")
       print(f"Total Calls    : {server_info.TotalCalls:10}")
       print(f"Total Users    : {server_info.TotalUsers:10}")
       print(f"Total Messages : {server_info.TotalMessages:10}")
       print(f"Total Files    : {server_info.TotalFiles:10}")
       print(f"Memory Usage   : {server_info.MemoryUsage:10}")
       print(f"Memory Load    : {server_info.MemoryLoad:10}")
       print(f"Last Message Id: {server_info.LastMessageId:10}")
       print(f"Last User Id   : {server_info.LastUserId:10}")
       print( "Version.Build  :",GetWildcatServerStr(server_info))
   else:
       print("Error getting server information")

# ----------------------------------------------------------
if 0:
   # Get the number of file areas
   file_area_count = GetFileAreaCount()
   print("- File Areas:",file_area_count)
   # Iterate through each file area
   for i in range(file_area_count):
       try:
           # Get the file area data
           # Allocate a TFileArea structure
           file_area = TFileArea()
           if GetFileArea(i+1, ctypes.byref(file_area)):
              # Print the file area data
              print("File Area #%d:" % (i+1), " Name: %-25s" % file_area.Name)
              #print("  ObjectId           :", file_area.ObjectId)
              #print("  Number             :", file_area.Number)
              #print("  Name               :", file_area.Name)
              #print("  FtpDirectoryName   :", file_area.FtpDirectoryName)
              #print("  ExcludeFromNewFiles:", file_area.ExcludeFromNewFiles)
              #print("  PromptForPasswordProtect:", file_area.PromptForPasswordProtect)
              #print("  Options            :", hex(file_area.Options))
           #else:
           #   print(f"Error getting file area {i} data")
       except Exception as e:
           print("Error ",e)


# ----------------------------------------------------------

class TSecurityName(ctypes.Structure):
    _fields_ = [('Name', ctypes.c_char*SIZE_SECURITY_NAME)]
    def __getattribute__(self, name):
        val = object.__getattribute__(self, name)
        if isinstance(val, bytes):
            return val.decode()
        return val

    def __setattr__(self, name, value):
        if isinstance(value, str):
            value = value.encode()
        object.__setattr__(self, name, value)

"""
//------------------------------------------------------------
// Dump Security Profiles. Please note this config API access
// is redundant as there is already a GetSecurityProfileXXXX()
// functions as part of the normal API.
//------------------------------------------------------------

sub DumpSecurityGroups
  dim count as integer = MwGetSecurityProfileCount()
  print "******* MwGetSecurityProfileCount(): ";count;" *************"
  dim list(count-1) as string*SIZE_SECURITY_NAME
  if (count > 0) then
      if MwGetSecurityProfileNames(0,count,@list) then
         dim i as integer
         for i = 0 to count-1
            print i;" [";list(i);"]"
         next
      else
          Print "MwGetSecurityProfileNames() Error #"; hex(GetLastError())
      end if
  end if
end sub

//------------------------------------------------------------
// Dump Access Profiles. Please note this config API access
// is redundant as there is already a GetAccessProfileXXXX()
// functions as part of the normal API. However, please note
// the "terminology" used via the Config API (wcsmw) of
// "GroupName".  This is the same as AccessProfile.
//------------------------------------------------------------

sub DumpGroupNames
  dim count as integer = MwGetGroupCount()
  print "******* MwGetGroupCount(): ";count;" *************"
  dim list(count-1) as string*SIZE_SECURITY_NAME
  if count > 0 then
      if MwGetGroupNames(@list) then
         dim i as integer
         for i = 0 to count-1
            print i;" [";list(i);"]"
         next
      else
          Print "MwGetGroupNames() Error #"; hex(GetLastError())
      end if
  end if
end sub

##DWORD APIENTRY MwGetSecurityProfileCount();
MwGetSecurityProfileCount = wildcat_dll.MwGetSecurityProfileCount
MwGetSecurityProfileCount.restype = ctypes.wintypes.DWORD

##BOOL APIENTRY MwGetSecurityProfileNames(DWORD index, DWORD count, char profilenames[][SIZE_SECURITY_NAME]);
MwGetSecurityProfileNames = wildcat_dll.MwGetSecurityProfileNames
MwGetSecurityProfileNames.argtypes = [ctypes.wintypes.DWORD, ctypes.wintypes.DWORD, ctypes.c_char]
MwGetSecurityProfileNames.restype = ctypes.wintypes.BOOL

##DWORD APIENTRY GetSecurityProfileCount();
GetSecurityProfileCount = wildcat_dll.GetSecurityProfileCount
GetSecurityProfileCount.restype = ctypes.wintypes.DWORD

##BOOL APIENTRY GetSecurityProfileNames(DWORD count, char names[][SIZE_SECURITY_NAME]);
GetSecurityProfileNames = wildcat_dll.GetSecurityProfileNames
GetSecurityProfileNames.argtypes = [ctypes.c_ulong, ctypes.POINTER(ctypes.c_char*SIZE_SECURITY_NAME)]
GetSecurityProfileNames.restype = ctypes.c_bool

##BOOL APIENTRY GetSecurityProfileByIndex(DWORD index, TSecurityProfile &profile);
GetSecurityProfileByIndex = wildcat_dll.GetSecurityProfileByIndex
GetSecurityProfileByIndex.argtypes = [ctypes.wintypes.DWORD, ctypes.POINTER(TSecurityProfile)]
GetSecurityProfileByIndex.restype = ctypes.wintypes.BOOL

##BOOL APIENTRY GetSecurityProfileByName(const char *name, TSecurityProfile &profile);
GetSecurityProfileByName = wildcat_dll.GetSecurityProfileByName
GetSecurityProfileByName.argtypes = [ctypes.c_char_p, ctypes.POINTER(TSecurityProfile)]
GetSecurityProfileByName.restype = ctypes.wintypes.BOOL


"""

if 0:
    ##BOOL APIENTRY GetSecurityProfileNames(DWORD count, char names[][SIZE_SECURITY_NAME]);
    # GetSecurityProfileNames = wildcat_dll.GetSecurityProfileNames
    # GetSecurityProfileNames.argtypes = [ctypes.c_ulong, ctypes.POINTER(ctypes.c_char*SIZE_SECURITY_NAME)]
    # GetSecurityProfileNames.restype = ctypes.c_bool

    count = GetSecurityProfileCount()
    print(f"Profile count: ",count)

    # Create the 2D array of fixed-length strings
    names = (ctypes.c_char * SIZE_SECURITY_NAME * count)()
    # Create a pointer to the 2D array
    names_pointer = ctypes.cast(names, ctypes.POINTER(ctypes.c_char * SIZE_SECURITY_NAME))

    # Call the function
    if GetSecurityProfileNames(count, names_pointer):
        for i in range(count):
            print(names[i].value.decode())
    else:
        print("Error getting security profile names")

if 0:
    ##BOOL APIENTRY GetSecurityProfileNames(DWORD count, char names[][SIZE_SECURITY_NAME]);
    GetSecurityProfileNames2 = wildcat_dll.GetSecurityProfileNames
    GetSecurityProfileNames2.argtypes = [ctypes.c_ulong, ctypes.POINTER(TSecurityName)]
    GetSecurityProfileNames2.restype = ctypes.c_bool


    count = GetSecurityProfileCount()
    print(f"Profile count: ",count)

    names = (TSecurityName * count)()

    # Call the function
    if GetSecurityProfileNames2(count, names):
        for i in range(count):
            print(names[i].Name)
    else:
        print("Error getting security profile names")


def read_text(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    return [line.strip() for line in lines]


def extract_arg_details(arg):
    match = re.match(r"(?P<const_kw>const)?\s*(?P<arg_type>char)\s*(?P<pointer_symbol>\*)\s*(?P<arg_name>\w+)(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?", arg)
    if match:
        const_kw = match.group('const_kw')
        arg_type = match.group('arg_type')+match.group('pointer_symbol')
        arg_name = match.group('arg_name')
        arg_array = match.group('arg_array')
        arg_size = match.group('arg_size')

        return const_kw, arg_type, arg_name, arg_array, arg_size
    else:
        return None, None, None, None, None

if 0:
   #see test-args.py

   # wcserverapi.txt
   api_list = read_text("wcserverapi.txt")
   for func_line in api_list:
      print("***",func_line)
      if func_line.lower() == "stop":
         break;

      # Extract function name, arguments and return type
      match = re.match(r"(?P<ret_type>\w+)?\s+(?P<call_conv>\w+\s+)?(?P<func_name>\w+)\s*\((?P<args>.*)\)\s*;", func_line)
      ret_type  = match.group('ret_type')
      call_conv = match.group('call_conv')
      func_name = match.group('func_name')
      args      = match.group('args')

      print(f"  ret_type : {ret_type}")
      print(f"  call_conv: {call_conv}")
      print(f"  func_name: {func_name}")
      print(f"  args     : {args}")

      if func_name in ["WildcatServerConnectLocal"]:
         break

      #continue;

      if args:
         # Extract the argument names and types from the arguments string
         arg_list = args.split(', ')
         for i, arg in enumerate(arg_list):

             print(f"{i:2}",arg)

             #match = re.match(r"(\w+) (\w+)(\[\]\[(\w+)\])?", arg)
             #arg_type, arg_name, arg_array, arg_array_size = match.groups()

             #match = re.match(r"(const\s+)?(\w+)\s+(\w+)(\[\]\[(\w+)\])?", arg)
             #const_kw, arg_type, arg_name, arg_array, arg_array_size = match.groups()


             #match = re.match(r"(?P<const_kw>const\s+)?(?P<arg_type>\w+)\s*\*?\s*(?P<arg_name>\w+)(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?", arg)
             #match = re.match(r"(?P<const_kw>const)?\s*(?P<arg_type>char)\s*(?P<pointer_symbol>\*)\s*(?P<arg_name>\w+)(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?", arg)
             #match = re.match(r"(?P<const_kw>const)?\s*(?P<arg_type>char)\s*(?P<pointer_symbol>\*)\s*(?P<arg_name>\w+)(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?", arg)

             const_kw, arg_type, arg_name, arg_array, arg_size = extract_arg_details(arg)

             #if const_kw is not None:
             #   print(f'const_kw={const_kw} arg_type={arg_type} arg_name={arg_name} arg_array={arg_array} arg_size={arg_size}')


             """
             const_kw = match.group('const_kw')
             arg_type = match.group('arg_type')+match.group('pointer_symbol')
             arg_name = match.group('arg_name')
             arg_array = match.group('arg_array')
             arg_size = match.group('arg_size')
             """


             print(f"{i:4} const_kw: {const_kw}")
             print(f"{i:4} arg_type: {arg_type}")
             print(f"{i:4} arg_name: {arg_name}")
             print(f"{i:4} arg_array: {arg_array}")
             print(f"{i:4} arg_size: {arg_size}")

             continue

             if arg_array:
                 new_class_name = arg_array_size
                 new_class_name = "T"+new_class_name.replace("SIZE_", "").lower().replace("_"," ").title().replace(" ","")
                 print(f"new_class_name: {new_class_name}")

                 class_definition = 'class {}(ctypes.Structure):\n    _fields_ = [("Name", ctypes.c_char * {})]\n'.format(new_class_name, arg_array_size)
                 print(f"class_definition: {class_definition}")

                 """
                 class TSecurityName(ctypes.Structure):
                     _fields_ = [('Name', ctypes.c_char * int(arg_array_size))]
                 func.argtypes = [ctypes.c_ulong, ctypes.POINTER(TSecurityName)]
                 """
             else:
                 ##func.argtypes.append(getattr(ctypes, arg_type))
                 print(getattr(ctypes.wintypes, arg_type))

      else:
         print("")
# ----------------------------------------------------------
if not WildcatServerDeleteContext():
   print("Error Deleting Wildcat! Server Context")
   exit(1)

input()
