import ctypes
from ctypes import wintypes
from ctypes.wintypes import *
import platform
import sys

if sys.maxsize > 2**31 - 1:
    print("Python is running in 64-bit environment")
else:
    print("Python is running in 32-bit environment")

arch, _ = platform.architecture()
if arch == '64bit':
    print("platform: Python is running in 64-bit environment")
else:
    print("platform: Python is running in 32-bit environment")

if ctypes.sizeof(ctypes.c_void_p) == 8:
    print("ctypes: Python is running in 64-bit environment")
else:
    print("ctypes: Python is running in 32-bit environment")

print("sizeof(DWORD): ", ctypes.sizeof(DWORD))

