
item_strings = ['', '', '{', 'wclogNone = 0,', 'wclogHourly,', 'wclogDaily, // default for most things', 'wclogWeekly,', 'wclogMonthly,', 'wclogUnlimitedSize,', 'wclogMaxSize}', 'TWildcatLogPeriod;']
item_strings = ['', '', '{', 'wclogNone = 0,', 'wclogHourly,', 'wclogDaily, // default for most things', 'wclogWeekly,', 'wclogMonthly,', 'wclogUnlimitedSize,', 'wclogMaxSize}', 'TWildcatLogPeriod', ';']

new_item_strings = []
for item in item_strings:
    if len(item) > 1 and (item.endswith('}') or item.endswith(';')):
        new_item_strings.extend([item[:-1], item[-1]])
    else:
        new_item_strings.append(item)

item_strings = new_item_strings

for item in item_strings:
   print(item)
