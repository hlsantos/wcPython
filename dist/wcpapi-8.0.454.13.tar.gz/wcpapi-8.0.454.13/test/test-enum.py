
def parse_enum(s):

    # Replace '\n' with ' ' to handle newline characters
    s = s.replace("\n", " ")

    # Split the string by " } " to separate the items and name
    split_s = s.split(" }")

    # Extract the items by splitting the first part of the split_s by ", "
    item_strings = split_s[0].strip("{}").split(",")

    # Initialize an empty list to store the items
    items = []

    # Iterate over each item string
    for item_string in item_strings:
        # Split the item string by " //" to separate the item and comment
        item_and_comment = item_string.split("//")

        # Extract the item from the first part of the split
        item = item_and_comment[0]

        # If there is a comment, extract it from the second part of the split
        comment = item_and_comment[1] if len(item_and_comment) > 1 else ""

        # Add the item and comment to the items list
        items.append((item, comment))

    # Extract the name by removing the "; " from the second part of the split_s
    print(split_s)
    name = split_s[1].strip(";")
    return [name,items]


# main
s ='''
 {
      wclogNone   = 0,
      wclogHourly,
      wclogDaily,           // default for most things
      wclogWeekly,
      wclogMonthly,
      wclogUnlimitedSize,
      wclogMaxSize} TWildcatLogPeriod;

'''
s = "{item1 //comment1,\n item2,\n item3 //comment3,\n item4 }\n name; "


name, items = parse_enum(s)
# Print the extracted items and name
print("Name: ", name)
for n, item in enumerate(items):
    print(f"{n:2} - {item}")

