import re
from io import StringIO

def get_print_output(*args, **kwargs):
    output = StringIO()
    print(*args, file=output, **kwargs)
    return output.getvalue()

DEBUG = 0
def PRINT(*args, **kwargs):
    s = get_print_output(*args,**kwargs)
    if DEBUG:
       print(f"{s}", end="")


def split_string(string):
    # split the string on spaces, brackets, semicolons and commas
    split_list = re.findall(r'[^{};,]+|[{};,]', string)
    result = []
    skip_until = None
    for item in split_list:
        #print(f"split_string item: {item}")
        if skip_until:
            if item == skip_until:
                skip_until = None
            continue
        if item == '/*':
            skip_until = '*/'
        elif item == ',' and not skip_until:
            result.extend([item, ''])
        else:
            result.append(item)
    return result

def extract_items_and_name(s):

    PRINT("** extract_items_and_name()")
    PRINT(f"0 s:|{s}|")

    if not '\n' in s and (all(word in s for word in ["typedef", "enum", "{", "}", ";"])):
        PRINT("# one line declaration")
        item_strings = split_string(s)
        for i, item in enumerate(item_strings):
            if "/*" in item:
                item_strings[i] = item.replace("/*","#").replace("*/","")
    else:
        s = s.replace("{","{\n")
        s = s.replace("}","}\n")
        s = s.replace(";",";\n")
        s = s.replace("typedef","typedef\n")
        s = s.replace("enum","enum\n")

        # Split the string by newline characters to separate the items
        item_strings = s.strip().split("\n")

        # Replace '\t' with ' ' to handle tab characters
        item_strings = [item_string.replace("\t", " ") for item_string in item_strings]

        # Replace '\n' with ' ' to handle newline characters and ravel the string
        item_strings = [" ".join(item_string.split()) for item_string in item_strings]

        # Remove the "typedef" prefix
        item_strings = [item_string.replace("typedef", "").strip() for item_string in item_strings]
        # Remove the "enum" prefix
        item_strings = [item_string.replace("enum", "").strip()for item_string in item_strings]

        # extend the list if necessary
        new_item_strings = []
        for item in item_strings:
            if len(item) > 1 and (item.endswith('}') or item.endswith(';')):
                new_item_strings.extend([item[:-1], item[-1]])
            else:
                new_item_strings.append(item)
        item_strings = new_item_strings

    PRINT("**")
    PRINT(item_strings)
    PRINT("--")
    enum_name  = ""
    enum_items = []
    left_brace = 0
    right_brace = 0
    done        = 0
    enum_value  = 0
    for i, item in enumerate(item_strings):
        #PRINT(f"item_string{i:2}: |{item}|")
        if item == "": continue
        if item == ",": continue
        if item.startswith("typedef"): continue

        if not left_brace and item == "{": left_brace = 1; continue
        if left_brace and not right_brace and item == "}": right_brace = 1; continue
        if right_brace and item == ";": done = 1; continue
        if right_brace and not done:
           enum_name = item
           continue

        PRINT(f"item_string{i:2}: |{item}|")

        # we should have an enum item here
        eitem    = item.split(",")

        ename    = eitem[0].strip()
        ecomment = eitem[1].strip() if len(eitem)>1 else ""
        evalue   = enum_value

        ename = ename.split("#")
        if len(ename) > 1:
           ecomment = "#"+ename[1]
        ename    = ename[0].strip()

        ename = ename.split("=")
        if len(ename) > 1:
           evalue = int(ename[1].split()[0].strip())
           enum_value = evalue
        ename  = ename[0].strip()

        #PRINT(f"item_string{i:2}: |{item}| eitem: {eitem}")
        enum_items.append((ename,evalue,ecomment.replace("//","#")))
        enum_value += 1


    PRINT("--")
    PRINT(f"enum_name: {enum_name}")
    for i, e in enumerate(enum_items):
        PRINT(f"{i:2}: |{e[0]:20}|{e[1]:10}|{e[2]}")
        #PRINT(f"{i:2}: |{e}|")

    PRINT("**")

    # Return the extracted items and name
    return enum_items, enum_name


def test(s,tag=""):
    print(f"tag: {tag}")
    items, name = extract_items_and_name(s)

    # Print the extracted items and name

    print("Name: ", name)
    for n, item in enumerate(items):
        print(f"{n:2} - {item}")

    input()


#---------- test data

s0  = "typedef enum {listUnixFormat=0,listMSDOSFormat} TFtpListTextFormat;"
s01 = "typedef enum {listUnixFormat=0 /* default */,listMSDOSFormat} TFtpListTextFormat;"

s1 = '''
typedef enum {
      wclogNone   = 0,
      wclogHourly,
      wclogDaily,           // default for most things
      wclogWeekly,
      wclogMonthly,
      wclogUnlimitedSize,
      wclogMaxSize} TWildcatLogPeriod;
'''

s2 = '''
typedef enum
{
    wclogNone   = 0,
    wclogHourly,
    wclogDaily,           // default for most things
    wclogWeekly,
    wclogMonthly,
    wclogUnlimitedSize,
    wclogMaxSize
} TWildcatLogPeriod;
'''

s3 = '''
typedef enum{
    wclogNone   = 0,
    wclogHourly,
    wclogDaily,           // default for most things
    wclogWeekly,
    wclogMonthly,
    wclogUnlimitedSize,
    wclogMaxSize
} TWildcatLogPeriod;
'''


# s4 ok
s4 = '''
typedef
enum
{
      wclogNone   = 2,
      wclogHourly,
      wclogDaily,           // default for most things
      wclogWeekly = 10,
      wclogMonthly,
      wclogUnlimitedSize,
      wclogMaxSize
}
TWildcatLogPeriod
;
'''


#test(s4,"S4")
#test(s0,"S0")
#test(s01,"S01")

#test(s1)
#test(s2, "S2")
test(s3,  "S3")

