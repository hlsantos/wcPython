import re

def extract_arg_details(arg):
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)(?P<arg_ptr>\s*\*)?(?P<arg_amp>\s*&)?\s*(?P<arg_name>\w+)\s*(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?"
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)(?P<arg_ptr>\s*\*)?(?P<arg_amp>\s*&)?\s*(?P<arg_name>\w+)((?P<arg_array>\[\])?(?P<arg_size>SIZE_\w+)?)"
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>(\w+|\w+\s+\*|\w+\s+&|\w+\s+\*\s+&))\s*(?P<arg_name>\w+)((?P<arg_array>\[\]\[(?P<arg_size>\w+)\])?)"
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)(?P<arg_ptr>\s*\*)?(?P<arg_amp>\s*&)?\s*(?P<arg_name>\w+)\s*(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?"
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)(\s*(?P<arg_ptr>\*)|\s*(?P<arg_amp>&))?\s*(?P<arg_name>\w+)((?P<arg_array>\[\]\[(?P<arg_size>\w+)\])?)"
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)\s*(?P<arg_ptr>\*|(?P<arg_amp>&))?\s*(?P<arg_name>\w+)((?P<arg_array>\[\]\[(?P<arg_size>\w+)\])?)"

    # fails,
    #  char names[][SIZE_SECURITY_NAME],
    #  unsigned __int64 *&p
    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)(?P<arg_ptr>\s*\*)?(?P<arg_amp>\s*&)?\s*(?P<arg_name>\w+)\s*(\[(?P<arg_array>\[\])?(?P<arg_size>\w+)?\])?"


    pattern = r"(?P<arg_const>const)?\s*(?P<arg_type>\w+)\s*(?P<arg_ptr>\*|(?P<arg_amp>&))?\s*(?P<arg_name>\w+)((?P<arg_array>\[\]\[(?P<arg_size>\w+)\])?)"


    print("** ",arg)
    match = re.match(pattern, arg)
    #print("  ",match.groupdict())

    for group in match.groupdict():
        print(f"  {group:10} {match.group(group) or ''}")

    if match:
        arg_const = match.group('arg_const') or ""
        arg_type = match.group('arg_type') or ""
        arg_ptr = match.group('arg_ptr')  or ""
        arg_amp = match.group('arg_amp')  or ""
        arg_name = match.group('arg_name')  or ""
        arg_array = match.group('arg_array')  or ""
        arg_size = match.group('arg_size')  or ""
        return arg_const, arg_type,arg_ptr,arg_amp, arg_name, arg_array, arg_size
    else:
        return None, None, None, None, None, None, None


def dothis(arg):

    arg_const, arg_type, arg_ptr, arg_amp, arg_name, arg_array, arg_size = extract_arg_details(arg)

    """
    print(f"** {arg}")
    print(f"  arg_const : {arg_const}")
    print(f"  arg_type : {arg_type}")
    print(f"  arg_ptr  : {arg_ptr}")
    print(f"  arg_amp  : {arg_amp}")
    print(f"  arg_name : {arg_name}")
    print(f"  arg_array: {arg_array}")
    print(f"  arg_size : {arg_size}")
    """

#-------------------------------

dothis("HWND parent")
dothis("const char *computername")
dothis("TMakewild &mw")
dothis("DWORD count")
dothis("unsigned __int64 *&p")
dothis("char names[][SIZE_SECURITY_NAME]")

input()



