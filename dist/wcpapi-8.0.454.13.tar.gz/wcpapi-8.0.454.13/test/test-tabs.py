"""
The oddity on this spacing is with the exception of the first tab, the spacing is 3 then it keeps with a spacing of
So my editor, QEdit by SemWare, my power programming text editor since the 80s, has these fields for tab settings:

Set Tab Width   : 4
Set Tab Type    : Soft
Tab Shift Blocks: Off

Are we using a base 0 for the screen cursor position, because a tab = 4 spaces will year

---------1---------2---------3---------4---------5
12345678901234567890123456789012345678901234567890

--------1---------2---------3---------4---------5
012345678901234567890123456789012345678901234567890

    |   |   |   |   |   |
def some_function():
    if condition1:
        statement1
        if condition2:
            statement2
            if condition3:
                statement3
                if condition4:
                    statement4
                    if condition5:
                        statement5


"""

s = "hector\tsantos\twas\there"
s = "1\t2\t3\t4\t5"
print("---------1---------2---------3---------4---------5")
print("1234567890"*5)
print(s)

exit(0)
